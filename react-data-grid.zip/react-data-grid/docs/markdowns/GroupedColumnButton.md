`GroupedColumnButton` (component)
=================================



Props
-----

### `name` (required)

type: `string`


### `onColumnGroupDeleted`

type: `func`

