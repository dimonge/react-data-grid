`AutoCompleteEditor` (component)
================================



Props
-----

### `column`

type: `shaperequire('../../PropTypeShapes/ExcelColumn')`


### `editorDisplayValue`

type: `func`


### `height`

type: `number`


### `label`

type: `any`


### `onCommit`

type: `func`


### `onFocus`

type: `func`


### `onKeyDown`

type: `func`


### `options`

type: `arrayOf[object Object]`


### `resultIdentifier`

type: `string`
defaultValue: `'id'`


### `search`

type: `string`


### `value`

type: `any`


### `valueParams`

type: `arrayOf[object Object]`

