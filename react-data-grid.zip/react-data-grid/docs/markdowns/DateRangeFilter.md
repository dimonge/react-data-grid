`DateRangeFilter` (component)
=============================



Props
-----

### `endDate`

type: `custom`


### `format` (required)

type: `string`


### `onApply`

type: `func`


### `onblur`

type: `func`


### `ranges` (required)

type: `object`


### `startDate`

type: `custom`


### `title` (required)

type: `string`

