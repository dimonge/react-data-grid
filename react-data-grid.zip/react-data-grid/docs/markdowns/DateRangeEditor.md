`DateRangeEditor` (component)
=============================



Props
-----

### `format`

type: `string`
defaultValue: `'YYYY-MM-DD'`


### `ranges`

type: `arrayOf[object Object]`
defaultValue: `[]`


### `value` (required)

type: `shape[object Object]`

