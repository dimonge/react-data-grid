`ImageFormatter` (component)
============================



Props
-----

### `value` (required)

type: `string`

