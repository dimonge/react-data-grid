`Toolbar` (component)
=====================



Props
-----

### `addRowButtonText`

type: `string`
defaultValue: `'Add Row'`


### `enableAddRow`

defaultValue: `true`


### `enableFilter`

type: `bool`


### `filterRowsButtonText`

type: `string`
defaultValue: `'Filter Rows'`


### `numberOfRows`

type: `number`


### `onAddRow`

type: `func`


### `onToggleFilter`

type: `func`

