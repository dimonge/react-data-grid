`DraggableHeaderCell` (component)
=================================



Props
-----

### `connectDragPreview` (required)

type: `func`


### `connectDragSource` (required)

type: `func`


### `isDragging` (required)

type: `bool`

