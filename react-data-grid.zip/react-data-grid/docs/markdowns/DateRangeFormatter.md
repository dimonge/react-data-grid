`DateRangeFormatter` (component)
================================



Props
-----

### `displayFormat`

type: `string`
defaultValue: `'YYYY-MM-DD'`


### `inputFormat`

type: `string`
defaultValue: `'YYYY-MM-DD'`


### `value` (required)

type: `shape[object Object]`
defaultValue: `{startDate: null, endDate: null}`

