`AutoCompleteTokensEditor` (component)
======================================



Props
-----

### `column`

type: `shape[object Object]`


### `options` (required)

type: `array`


### `value`

type: `array`

