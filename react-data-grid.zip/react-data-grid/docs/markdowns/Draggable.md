`Draggable` (component)
=======================



Props
-----

### `component`

type: `union(func|custom)`


### `onDrag`

type: `func`
defaultValue: `() => {}`


### `onDragEnd`

type: `func`
defaultValue: `() => {}`


### `onDragStart`

type: `func`
defaultValue: `() => true`

