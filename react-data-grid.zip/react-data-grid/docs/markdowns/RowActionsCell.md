`RowActionsCell` (component)
============================



Props
-----

### `column`

type: `object`


### `connectDragPreview` (required)

type: `func`


### `connectDragSource` (required)

type: `func`


### `dependentValues`

type: `object`


### `isDragging` (required)

type: `bool`


### `isRowHovered`

type: `bool`


### `rowIdx` (required)

type: `number`
defaultValue: `0`


### `rowSelection` (required)

type: `object`


### `value`

type: `bool`

