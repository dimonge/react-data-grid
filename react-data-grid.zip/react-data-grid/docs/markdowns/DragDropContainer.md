`DragDropContainer` (component)
===============================



Props
-----

### `children` (required)

type: `element`


### `getDragPreviewRow`

type: `func`

