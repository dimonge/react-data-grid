`DropDownEditor` (component)
============================



Props
-----

### `options` (required)

type: `arrayOf[object Object]`

