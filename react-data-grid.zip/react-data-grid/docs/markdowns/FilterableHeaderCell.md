`FilterableHeaderCell` (component)
==================================



Props
-----

### `column`

type: `shaperequire('../../../PropTypeShapes/ExcelColumn')`


### `onChange` (required)

type: `func`

