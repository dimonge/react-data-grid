`RowDragLayer` (component)
==========================



Props
-----

### `columns` (required)

type: `array`


### `currentOffset`

type: `shape[object Object]`


### `isDragging` (required)

type: `bool`


### `item`

type: `object`


### `itemType`

type: `string`


### `rowSelection`

type: `object`


### `rows` (required)

type: `array`

