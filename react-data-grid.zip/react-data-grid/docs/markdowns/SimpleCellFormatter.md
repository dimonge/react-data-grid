`SimpleCellFormatter` (component)
=================================



Props
-----

### `value` (required)

type: `union(string|number|object|bool)`

