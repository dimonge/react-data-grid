`EditorContainer` (component)
=============================



Props
-----

### `cellMetaData` (required)

type: `shape[object Object]`


### `column` (required)

type: `object`


### `height` (required)

type: `number`


### `rowData` (required)

type: `object`


### `rowIdx`

type: `number`


### `value` (required)

type: `union(string|number|object|bool)`

