`GroupedColumnsPanel` (component)
=================================



Props
-----

### `canDrop` (required)

type: `bool`


### `connectDropTarget`

type: `func`


### `groupBy`

type: `array`


### `isOver` (required)

type: `bool`


### `noColumnsSelectedMessage`

type: `string`
defaultValue: `'Drag a column header here to group by that column'`


### `onColumnGroupDeleted`

type: `func`


### `panelDescription`

type: `string`
defaultValue: `'Drag a column header here to group by that column'`

