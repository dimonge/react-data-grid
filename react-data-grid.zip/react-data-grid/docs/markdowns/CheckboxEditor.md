`CheckboxEditor` (component)
============================



Props
-----

### `column`

type: `shape[object Object]`


### `dependentValues`

type: `object`


### `rowIdx`

type: `number`


### `value`

type: `bool`

