`MenuHeader` (component)
========================



Props
-----

### `children`

type: `any`

