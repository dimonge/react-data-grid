`EditorBase` (component)
========================



Props
-----

### `column` (required)

type: `shaperequire('../../PropTypeShapes/ExcelColumn')`


### `commit` (required)

type: `func`


### `onBlur` (required)

type: `func`


### `onKeyDown` (required)

type: `func`


### `value` (required)

type: `any`

