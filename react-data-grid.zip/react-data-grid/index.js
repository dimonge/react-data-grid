module.exports = require("./dist/react-data-grid");
